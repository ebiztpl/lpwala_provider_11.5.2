import 'dart:io';

class FileModel {
  String? id;
  File? file;
  String? filePath;

  FileModel({this.id, this.file, this.filePath});
}
