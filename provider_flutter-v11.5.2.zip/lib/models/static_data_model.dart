class StaticDataModel {
  String? key;
  String? value;

  StaticDataModel({this.key, this.value});
}
